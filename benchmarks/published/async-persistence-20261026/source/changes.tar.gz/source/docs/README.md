# 文档导航

当前实现为固定三个 voter、单 Raft Group 的 C++17 KV 服务，默认使用增量 journal、ReadIndex、自适应快照与同步编码，支持可选后台编码和 revision／CAS。最新普通／ASan 各 186 项、队列与后台执行组件 TSan 31 项已通过；可选后台磁盘执行已接入，默认服务仍同步落盘。三机六小时窗口、恢复与持久化／读等待关联的历史范围分列如下。

## 使用与开发

| 需要做的事 | 入口 |
| --- | --- |
| 构建、测试、启动和读写 | [项目首页](../README.md) |
| 修改代码与提交前检查 | [开发说明](../CONTRIBUTING.md) |
| 本机服务、状态、超时、备份和恢复 | [集群操作](cluster.md) |
| 三台云服务器私网部署与系统级服务 | [云服务器部署](cloud-deployment.md) |
| 对现有三机测吞吐量、P95/P99 和不同并发 | [跨机压测操作](cloud-benchmark.md) |
| 关联读请求、ReadIndex 与副本 RPC 的分阶段耗时 | [读路径追踪](read-tracing.md) |
| 关联同线程读等待、持久化编码、文件和目录同步 | [持久化时间关联](persistence-tracing.md) |
| 后台磁盘线程、非阻塞 Raft 与故障确认顺序 | [后台磁盘执行](background-persistence.md) |
| 持久化任务接收、顺序、完成通知与确认边界 | [有序持久化接口](persistence-queue.md) |
| 版本条件更新、多发布者冲突与旧快照迁移 | [CAS 契约](cas.md) |
| 冻结值的所有权、后台编码与暂停边界 | [后台快照编码](background-snapshot.md) |
| 持久化分桶、CAS 历史、C++ 发压与长窗口 | [长窗口验证工具](long-window.md) |
| 配置发布、HTTP 消费者和动态刷新 | [配置应用](../examples/README.md) |
| 跑性能对照或故障活动 | [实验复现](../benchmarks/README.md) |
| 当前进度、后续方向和放行标准 | [工程路线](roadmap.md) |

## 设计与正确性契约

| 主题 | 文档 |
| --- | --- |
| 网络、存储与模块边界 | [总体设计](design.md) |
| 状态机、持久化和传输层的职责 | [Raft 集成契约](raft-contract.md)、[模块说明](../src/raft/README.md) |
| 文件格式、校验、原子发布和失败处理 | [Raft 持久化](raft-persistence.md)、[增量 journal](journal.md) |
| 新鲜多数派确认、应用位置和读写重叠 | [ReadIndex](read-index.md) |
| 快照触发、日志回收、容量和磁盘兼容性 | [快照契约](snapshots.md) |

## 实验与验收

按时间从新到旧排列。每份报告注明对应版本、负载、恢复检查、限制与证据状态。云端归档保留故障输出、环境、服务日志及新增的逐请求性能样本；同机归档另有模型历史。各自的源码快照与文件清单可离线核验。

| 版本与变化 | 回归 | 性能与故障活动 | 原始证据 |
| --- | --- | --- | --- |
| [2026-10-26：后台磁盘与非阻塞 Raft](background-persistence.md) | 普通／ASan 各 186 项；队列与后台执行组件 TSan 31 项 | 真实后台路径的慢盘心跳、读写屏障、SIGKILL、磁盘失败、CAS 与快照追赶；无云端性能结论 | [源码增量、首次失败与完整回归](../benchmarks/published/async-persistence-20261026/README.md)，默认同步执行 |
| [2026-10-26：有序持久化接口第一阶段](persistence-queue.md) | 普通／ASan 各 169 项，新增组件 15 项 | 实际 Raft／磁盘的可控完成通知、同步后失败、原始字节等价与恢复；修正追踪测试的偶发零交集假设 | [源码增量与回归日志](../benchmarks/published/persistence-queue-20261026/README.md)，未接入生产后台线程，未做性能测量 |
| [2026-10-25：持久化与慢读时间关联](cloud-persistence-trace-20261025.md) | 普通／ASan 各 154 项；公开证据语义负例单列 | 12 个 30 秒窗口、212,268 次成功、3,732 个未发时刻；开启组 53,065 个 GET 全部关联，保留观测开销与最坏 376.734 ms 请求 | [原始数值、源码、日志与复算](../benchmarks/published/persistence-trace-20261025/README.md)，后台磁盘发布未实现 |
| [2026-10-24 / 25：六小时三机稳定性与恢复](cloud-soak-20261024.md) | 复用短任务 148 项及日历修正专项；新离线语义负例单列 | 360 个一分钟窗口、12,872,548 次已发请求成功；87,452 个计划时刻未发；六次整组重启验证；保留 520.703 ms 最长请求 | [全部逐请求样本、资源、源码与核验](../benchmarks/published/cloud-soak-20261024/README.md)，每配置一个约一小时相位，客户端共置 |
| [2026-10-24：分阶段指标、CAS 模型与 C++ 发压工具](long-window.md) | 普通／ASan 各 148 项；日历修正后另有专项回归 | CAS 强杀／暂停／隔离历史、错值／样本上限／中断保存；长窗口方案的实际结果见上一行 | [短任务证据](../benchmarks/published/tooling-20261024/README.md)与[日历边界记录](../benchmarks/published/tooling-calendar-20261024/README.md) |
| [2026-10-24：故障、后台快照、容量与 CAS](engineering-next-20261024.md) | 普通／ASan 各 143 项；状态机／快照组件 TSan 13 项 | 18 轮故障、2,491 个模型操作；42 轮正式负载、637,823 个已发请求；固定快照压力下吞吐 +40.46%、P99 −34.88%，仍有同步发布暂停 | [公开证据](../benchmarks/published/engineering-20261024/README.md)：全部 48 轮含探索数据、资源、工具、升级与清理；未发计划请求单列 |
| [2026-10-24：调度追踪与原程序 CPU 亲和性对照](cloud-scheduling-20261024.md) | 开发机普通／ASan 各 134 项；RPC／记录器组件 TSan 9／4 项 | 追加 20 轮、2,607,683 次纯读；原程序固定负载吞吐中位数 +32.0%、P99 43.225→7.617 ms，仍有 87.525 ms 单次尾部；默认配置已恢复 | [48 轮公开数值证据](../benchmarks/published/cloud-diagnosis-20261024/README.md)：全部请求样本、数值追踪和解码调度事件；原始包捕获仍私有 |
| [2026-10-24：ReadIndex 分阶段追踪与三机尾延迟诊断](cloud-read-trace-20261024.md) | 开发机普通／ASan 各 134 项；记录器组件 TSan 4 项 | 28 轮、2,416,980 次纯读；有效关联 14,357 条读追踪，保留约 43 ms 的 P99 及多处等待；云端恢复原程序 | [48 轮公开数值证据](../benchmarks/published/cloud-diagnosis-20261024/README.md)；抓包结论为摘要，独立包级重算仍需私有捕获 |
| [2026-10-24：三台 ECS 跨机性能基线](cloud-performance-20261024.md) | 节点仍为已验收的 `909df76` 二进制，工具为 `c1b238c`；未重新执行云端 CTest | 45 轮、1,954,767 次计时请求；三种读写负载、五档并发、三次重复；保留高并发读尾延迟与最坏单次 152.175 ms | [核验入口](../benchmarks/published/cloud-performance-20261023/README.md)：逐请求样本、三台环境、CSV、图表与源码 |
| [2026-10-23：三台 ECS 基础正确性手工演练](cloud-acceptance-20261023.md) | 三台各 126 项普通构建通过，源码与运行二进制哈希一致 | 两次服务停止接管、一个 Follower 虚拟机重启、少数派保护及全停恢复；无跨机性能测量 | [核验入口](../benchmarks/published/cloud-20261023/README.md)：五项故障的文本记录；初始三条读写序列只有截图 |
| [2026-10-22：读写重叠、自适应快照与 CRC 优化](local-followup-20261022.md) | 普通／sanitizer 各 125 项，磁盘补充 43 项 | 72 轮、4,353,146 次计时操作；一小时、3,302 轮、176,543 次模型操作 | [核验入口](../benchmarks/published/local-followup-20261022/README.md) |
| [2026-10-21：增量 journal、ReadIndex 与配置应用](local-optimization-20261021.md) | 普通／sanitizer 各 120 项，磁盘补充 13 项 | 36 轮、1,265,078 次计时操作；20 分钟、1,143 轮、61,113 次模型操作 | [核验入口](../benchmarks/published/local-optimization-20261021/README.md) |
| [2026-10-21：image／日志读与快照基线](local-acceptance-20261021.md) | 普通／sanitizer 各 103 项 | 27 轮、348,770 次计时操作；15 分钟、948 轮、50,970 次模型操作 | [核验入口](../benchmarks/published/local-20261021/README.md) |

验收日志中的“磁盘补充”不与完整回归数相加。性能操作、并发模型操作和顺序持久值检查分别计数。较早的单节点实验位于 `benchmarks/results/` 中已跟踪的历史目录，解释见[实验说明](../benchmarks/README.md)。

2026-10-22 的同机性能报告保留了均衡负载 P99.9 变差及大状态单次约 164 ms 的结果。三机基线保留高并发尾部；最新后台编码对照也保留最坏 299.259 ms 请求、最长发布暂停及 148,257 个未发计划时刻。磁盘检查点仍同步发布；这些有限实验不包含真实断电、多日稳定性或生产容量验收。
