# 2026-10-22 本机读调度、检查点与故障验证

本轮继续使用一台电脑上的三个独立测试进程，不租用服务器。改动与结果只适用于固定三个 voter、单 Raft Group、回环网络及现有容量限制。

## 实现

### 读确认与写复制重叠

运行时为已收到的 GET 记录任期和先前写入的应用位置，先登记新的 ReadIndex 轮次，再持久化同批写提案。Raft 核心把 AppendEntries 的构造推迟到 `TakeMessages()` 交付传输层时，因此新 context 可以与尚未交付的写复制共用请求。已经交付的旧请求不改 context，旧回复和重复旧回复不能完成之后收到的读。

返回读结果仍要求当前任期已提交条目、新 context 的多数派确认，以及状态机达到 ReadIndex 和先前写入两个应用位置。失去领导权、任期变化、超时和有界等待额度的处理保留。该路径不使用 Leader lease。

`status` 新增 read_overlapped_requests、append_requests、read_append_requests 和 read_append_with_entries，用于检查实际是否合并了复制，而非仅凭吞吐推断。

### 大活跃集合的检查点成本

默认 `--snapshot-policy adaptive`：达到条目阈值时，还要求保留日志字节至少为 `min(snapshot_bytes, live_snapshot_bytes / 4)`；原字节阈值仍独立触发。小集合保持原有条目回收节奏，大集合减少少量小更新引发的全量重写。`--snapshot-policy fixed` 保留旧策略，可在同一二进制内进行对照。

CRC32 用查表替代逐字节八次位运算，保持 IEEE 多项式、初始值、取反及磁盘字节格式。独立的逐位编码器检查二进制 payload 和快照的校验和兼容性。检查点仍同步生成；本轮没有把落盘确认移到后台或删除文件／目录同步。

新增 snapshot_pause_ns 和 snapshot_pause_max_ns，覆盖状态序列化、验证、检查点同步及发布。累计最大值包含预填充，不能相减得到计时窗口最大值；旧版本缺少这些计数，不能把缺失的零值当作零成本。

### 故障与跨轮次恢复检查

测试专用 I/O 库新增正常短写、写入半条日志后 EIO，以及副本同步变慢。验证完整写循环、失败节点停止服务、已确认值保留和故障解除后的追赶。注入只影响独立测试进程的 Raft 文件。

持续故障活动保留六类故障与有界逐 key 历史模型，新增最多 32 个循环更新的持久 key。每轮先检查此前已确认值经历本轮故障后仍可读取，再确认新的更新；结束时全节点 SIGKILL／重启，重新检查完整集合。它们与并发模型的操作计数分开统计。未知写入仍以可选、无完成时间上界保留。

## 已完成的回归

- 普通构建完整 CTest **125/125** 通过。
- ASan／UBSan 完整 CTest **125/125** 通过，启用泄漏检查。
- 工作区磁盘文件系统补充测试 **43/43** 通过，覆盖 journal、镜像、快照、资源错误、ReadIndex、配置应用及故障活动。
- 全部 **73** 个 C++ 文件通过 clang-format 18 检查；新增 Python 文件可编译。
- 先前两轮公开证据重新核验通过，未改写历史结果。

第一次 sanitizer 回归因测试工具释放节点预留端口后被代理选中而启动失败。已保留失败日志，改为在代理绑定完成前一直占用节点端口，并重跑完整回归通过。

## 实验方法

冻结上一轮默认版本和本轮构建，保存源码归档、构建环境与二进制 SHA-256。测试数据位于工作区磁盘，测试、编译和故障活动不与性能测量并行。

读路径实验交错比较旧默认、新默认与新版本 log 读路径，五种负载各重复三次，每轮计时 15 秒。当前同二进制的两种读模式可比较 ReadIndex 开销；跨版本结果包含本轮所有改动，不能把收益全部归因于单一调度修改。

检查点实验分别预填充 1／8／15 MiB 不常修改的 value，再由八个客户端读写各自的小热 key，保留旧版本、新版本 fixed 和新版本 adaptive 三种对照。后两者仅改变快照策略，可用于隔离频率调整的影响。每轮结束后强杀三个节点，重启并核对全部 cold／hot 最终值；预填充与恢复均不计入吞吐与请求延迟。

逐请求样本保留完成时间、延迟和读写类型；核验会重新计算 P50／P95／P99／P99.9／最大值、逐秒分桶、操作比例和持久化差值。汇总取独立运行统计量的中位数。三节点、代理与负载发生器共享四个逻辑 CPU；没有隔离后台服务、固定 CPU 频率或磁盘缓存，因此这些是开发对照，不是生产饱和或扩展性数据。

## 结果

性能与延长故障活动正在运行；本节将在完整核验后填写。

## 仍保留的边界

检查点仍在节点工作线程同步生成，单次较大检查点仍可能阻塞请求；降低频率不能消除所有最长暂停。自适应策略会保留更多后缀条目，须同时观察重启重放成本。活跃编码快照上限仍为 16 MiB，逻辑状态上限仍为 64 MiB。

有限故障历史、sanitizer 和有界模型检查不等于形式化证明。跨机器、宿主机故障、真实断电、多日运行、成员变更、认证和跨 key 事务尚不属于本轮验证结论。

## 复现

先保存旧版本二进制及对应源码，再构建本轮；运行时不要覆盖被测二进制：

```bash
python3 benchmarks/local_followup.py --baseline /absolute/path/to/prior/yewukv-node \
  --node build/bin/yewukv-node --suite reads --duration-seconds 15 --repeats 3 \
  --output benchmarks/results/my-followup-reads
python3 benchmarks/local_followup.py --baseline /absolute/path/to/prior/yewukv-node \
  --node build/bin/yewukv-node --suite snapshots --duration-seconds 15 --repeats 3 \
  --output benchmarks/results/my-followup-snapshots
python3 scripts/cluster-soak.py --node build/bin/yewukv-node --client build/bin/yewukv-client \
  --output benchmarks/results/my-followup-faults --duration-seconds 3600
```

`--duration-seconds 86400` 可用于后续 24 小时活动；本轮的实际运行时间以结果与 manifest 为准。保持运行机器、磁盘空间和电源可用，保留失败目录和进度文件；多日运行结果不能由较短测试推算。
