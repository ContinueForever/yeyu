#!/usr/bin/env python3
"""Recheck published read/checkpoint samples and cross-epoch durability histories.

Only retained evidence is checked; this does not rerun processes or hardware.
"""
import argparse
import gzip
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "benchmarks"))
import local_followup

spec = importlib.util.spec_from_file_location("prior_evidence", ROOT / "scripts/verify-local-optimization.py")
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)


def verify_durability(directory):
    ring, checks, epochs = {}, 0, 0
    with gzip.open(directory / "epochs.jsonl.gz", "rt") as source:
        for line in source:
            record = json.loads(line)
            history, result = record["history"], record["result"]
            durability = history["durability"]
            expected = [dict(key=k.hex(), value=v.hex()) for k, v in sorted(ring.items())]
            prior.require(durability["verified_before_update"] == expected,
                          "cross-epoch acknowledged values were not all checked")
            prior.require(result["durable_ring_values_checked"] == len(ring), "durability count differs")
            key = f"soak-ring-{epochs % 32}".encode()
            value = f"acknowledged-epoch-{epochs}".encode()
            prior.require(durability["acknowledged_update"] == dict(key=key.hex(), value=value.hex()),
                          "acknowledged ring update differs")
            checks += len(ring)
            ring[key] = value
            epochs += 1
    summary = json.loads((directory / "summary.json").read_text())
    recovery = summary["final_recovery"]
    prior.require(recovery["all_node_sigkill"] and recovery["anchor_checked"], "final restart was not checked")
    prior.require(recovery["durable_ring_values"] == [dict(key=k.hex(), value=v.hex())
                  for k, v in sorted(ring.items())], "final recovered ring differs")
    prior.require(epochs == summary["epochs"], "durability epoch count differs")
    return checks + len(ring)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    root = parser.parse_args().directory.resolve()
    count = prior.verify_files(root)
    for name in ("reads", "snapshots"):
        local_followup.verify(root / name)
    epochs, checked = prior.verify_faults(root / "faults")
    durable = verify_durability(root / "faults")
    print(json.dumps(dict(verified=True, published_files=count, fault_epochs=epochs,
                          model_checked_operations=checked, cross_epoch_durability_checks=durable)))


if __name__ == "__main__":
    main()
