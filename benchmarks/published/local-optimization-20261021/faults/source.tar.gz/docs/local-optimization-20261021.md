# 2026-10-21 本机持久化、ReadIndex 与配置应用优化

## 实现范围

- 默认增量同步 journal，加上原子发布、按代次绑定的检查点；旧 image 模式保留作对照。普通追加不重写 KV 快照或已保留日志前缀。
- 默认 GET 使用安全 ReadIndex：当前任期提交门槛、新请求对应的新 context、多数派确认、应用位置屏障及超时／任期变化取消。日志读模式保留作对照。
- 原有 100 × 1000 步逻辑故障模拟之外，增加 100 × 1500 步的读写／分区／重启／快照模拟；持续真实进程故障加入 Leader 暂停与恢复。
- 加强逐 key 历史检查器的输入验证和相邻时间区间顺序，未知写入继续按可选、无完成时间上界处理。
- 增加配置发布、内容 revision、轮询刷新、功能开关与过期健康状态的应用；验证切主、无多数派、恢复和全节点重启。

详细契约：[journal](journal.md)、[ReadIndex](read-index.md)、[配置应用](../examples/README.md)。

## 已通过的回归

普通构建和 ASan/UBSan 构建完整 CTest 各 **120/120** 通过；sanitizer 启用泄漏检测。优化前留存的基线为 103/103。新增 Python 可编译，原有 421 个公开证据文件、348,770 个性能样本和 948 轮旧故障历史也重新校验通过。

新增 journal 测试检查尾部各位置截断、完整记录损坏、旧格式导入、冲突替换与截断、轮转回收、缺失文件，以及追加三边界和检查点四边界 SIGKILL。错误会使实例停止继续提供数据。备份验证新增了检查点指定 journal 的存在性检查。

真实 RPC 验证连续 100 次 GET 不增加任何副本的日志位置、持久化次数或写入字节；混合流水线的 GET 等待此前 PUT 应用；隔离旧 Leader 无法成功读本地值，读等待额度受限。原有 ENOSPC/EIO 注入、快照传输、落后副本追赶、已确认数据恢复和并发历史测试继续通过。

本机沙箱禁止 socket 创建及 LeakSanitizer 进程检查；完整网络／sanitizer 测试在获准的本机执行环境中完成。测试使用自己的临时数据和随机回环端口。

## 性能与故障证据

正式实验完成后在本节记录结果；原始性能与持续故障工具分别为 `benchmarks/local_optimization.py` 和 `scripts/cluster-soak.py`。所有节点、代理与发压进程都运行在同一台机器，不能外推跨主机容错或生产吞吐。

## 复现

```bash
cmake --build build -j2
ctest --test-dir build --output-on-failure -j2
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
  ctest --test-dir build-asan --output-on-failure -j2

# 同一二进制，三种模式，四种负载，每种三轮、10 秒；不要并行运行其他压力活动。
python3 benchmarks/local_optimization.py --node build/bin/yewukv-node \
  --output benchmarks/results/local-optimization-new --duration-seconds 10 --repeats 3

# 带六类真实进程／网络故障的有界历史活动，保留每轮输入与结果。
python3 scripts/cluster-soak.py --node build/bin/yewukv-node --client build/bin/yewukv-client \
  --output benchmarks/results/journal-soak-new --duration-seconds 1200
```

手动 CI 工作流 `extended-local-reliability` 支持 60–3600 秒的故障活动并保存历史。它不会定时运行；本轮没有触发远端 CI。

## 尚未覆盖的范围

固定三个 voter、单 Raft Group、回环部署、16 MiB 活跃编码快照和 64 MiB 逻辑状态上限保留。检查点仍全量编码，接近活跃容量上限时的延迟需要另行测量。真实断电、跨主机、多日运行、在线成员变更、认证和跨 key 事务未在本轮验证。有限测试和有界穷举不能替代形式化证明。

v3 journal 目录不能直接交给旧程序或 image 模式打开；升级应整组停机、备份后统一切换，回退使用升级前的整组备份。
