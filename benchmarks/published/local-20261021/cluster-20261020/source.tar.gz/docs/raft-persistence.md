# Raft 磁盘持久化（2026-10-20）

`raft::FileStore` 为已有 `Election`、`RaftLog` 提供真实磁盘存储，完成 G1 的持久化基础。它尚未接入 KV 服务；三节点、网络复制、选举时钟及线性一致读仍待实现。

## 数据及接口

- `HardStateStore::Save` 保存 `currentTerm` 和 `votedFor`，拒绝任期倒退和同一任期改投／清除已有投票。
- `LogStore::ReplaceFrom` 保留指定索引之前的前缀，替换整个后缀；空后缀可以截断。日志索引必须从 1 连续递增，term 非零且不下降，不得超过已保存的 currentTerm。
- `ReadState()` 返回一致的 hard state 和日志副本。已失败的实例禁止读取及继续写入，须销毁后重新打开。
- 每个节点使用独立目录，例如 `node-1/raft`。该目录用 `LOCK` 做进程独占，不能与 KV `WalEngine` 共用同一个目录。

初始化示例：

```cpp
raft::FileStore store("node-1/raft");
auto recovered = store.ReadState();
raft::Election election(1, {1, 2, 3}, recovered.hard_state, store);
raft::RaftLog log(std::move(recovered.entries), 0, store);
```

调用方必须为当前 Election/RaftLog 提供唯一的节点状态机所有者和固定 voter 配置，并以磁盘日志末尾生成投票请求。磁盘文件目前不绑定 node ID/voter 配置，不能将不同节点的目录互换。处理较高任期的 AppendEntries 时，先验证发送方身份并通过选举核心持久化任期，再调用日志核心；存储成功前不能发送批准投票或追加成功回复。

## 原子写入协议

每次更新将 **hard state 与完整日志一起** 编码为一个镜像：

1. 持有目录锁，移除上一次中断留下的 `raft.state.tmp`。
2. 独占新建临时文件并写完整镜像。
3. `fdatasync` 临时文件。
4. 原子 `renameat` 替换 `raft.state`。
5. `fsync` 所在目录，然后更新内存状态并返回成功。

初始化也会同步目录祖先，覆盖新创建目录的持久性。恢复时只读取发布文件并再次同步目录，避免上次进程在 rename 后、目录同步前退出后，新的同状态 Save 未经目录同步就返回成功。

目录同步是单独必要的步骤，见 [Linux fsync 手册](https://man7.org/linux/man-pages/man2/fsync.2.html)。写入或同步失败后，本实例停止服务；rename 之后失败时磁盘可能已经是新镜像，调用方不得把失败理解成“写入一定没发生”。

## 磁盘格式 v1

所有整数使用大端；命令是允许包含 NUL 的原始字节。

| 字段 | 字节数 |
| --- | ---: |
| magic `YRFT` | 4 |
| version `1` | 4 |
| currentTerm | 8 |
| votedFor（0 表示未投票） | 8 |
| entry count | 8 |
| 每条日志：index / term / command length / command | 8 / 8 / 4 / 可变 |
| CRC32（覆盖此前所有字节） | 4 |

恢复会检查文件类型、版本、总大小、CRC、条目数量、命令边界、连续索引及任期规则。发布文件截断、损坏或出现多余字节时拒绝启动，保留原文件；不能通过清空文件“恢复”，否则可能忘记已投出的票。临时文件不是恢复候选，始终以发布文件为准。

## 容量与安全边界

- 默认镜像上限 64 MiB；可通过 Options 调小，用于资源控制和测试。单条命令最多 1 MiB。
- 每次更新全量复制、校验并重写日志，时间／空间开销随日志长度增长。这是正确性基线，尚不是高吞吐分段 WAL。
- 这里的镜像是磁盘编码方式，不是 Raft InstallSnapshot 或状态机快照；尚无日志压缩协议。
- commit/applied index、leader 角色、选举时钟与复制进度不在该文件中。重启后的日志可能包含未提交条目，不能全部直接应用到 KV。
- 首次节点集成应采用空内存状态机，由协议重新确认提交位置后按序回放；不能直接复用独立 KV 服务的已应用 WAL 作为 Raft 日志。
- 持久性依赖本地文件系统正确执行 `fdatasync`、原子替换和 `fsync`。已覆盖进程崩溃，没有进行真实断电、磁盘控制器故障或网络文件系统验收。

## 验证

本次验证：完整 CTest **73/73 通过**；ASan/UBSan 下全部 Raft 测试 **32/32 通过**，启用泄漏检查。新增模块没有连接运行中的 KV 服务，现有网络、单机 WAL 与恢复测试均包含在完整回归中。

新增 18 项 `RaftFileStore` 测试，与已有 14 项 Raft 规则测试一起运行：

```bash
./build/bin/yewu_tests --gtest_filter='Raft*'
ctest --test-dir build --output-on-failure -j2
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
  ./build-asan/bin/yewu_tests --gtest_filter='Raft*'
```

核心测试覆盖实际磁盘上的重启投票限制、冲突后缀替换、截断及继续追加；所有长度的截断镜像、CRC 错误及 CRC 正确但语义非法的镜像都会被拒绝。写盘故障注入覆盖文件同步前、rename 前、目录同步前及同步后，检查失败实例停用和重新打开后的状态。真实 SIGKILL 覆盖同样四个阶段的后缀替换，以及对已经成功返回的投票和追加进行强杀恢复。

SIGKILL 测试证明进程崩溃下的行为；rename 后但目录未同步的断电结果仍取决于文件系统，不能把进程测试表述为断电实验。
