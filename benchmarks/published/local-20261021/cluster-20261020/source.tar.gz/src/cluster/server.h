#pragma once

#include <cstdint>
#include <cstddef>
#include <map>
#include <memory>
#include <string>

namespace yewukv::cluster {

struct Endpoint {
  std::string host;
  uint16_t port = 0;
};

struct Options {
  uint64_t id = 0;
  uint16_t port = 0;
  std::map<uint64_t, Endpoint> members;
  std::string directory;
  uint32_t seed = 1;
  int request_timeout_ms = 1500;
  size_t proposal_batch_size = 32;
};

class Server {
 public:
  explicit Server(Options options);
  ~Server();
  Server(const Server&) = delete;
  Server& operator=(const Server&) = delete;
  bool Run(int stop_fd);

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

}  // namespace yewukv::cluster
