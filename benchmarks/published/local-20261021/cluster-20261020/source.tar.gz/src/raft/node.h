#pragma once

#include <array>
#include <cstdint>
#include <map>
#include <optional>
#include <random>
#include <vector>

#include "raft/file_store.h"

namespace yewukv::raft {

enum class MessageKind { kVote, kVoteReply, kAppend, kAppendReply };

struct Message {
  MessageKind kind = MessageKind::kVote;
  uint64_t from = 0;
  uint64_t to = 0;
  uint64_t sequence = 0;
  uint64_t term = 0;
  uint64_t last_index = 0;
  uint64_t last_term = 0;
  bool granted = false;
  AppendRequest append;
  bool success = false;
  uint64_t match_index = 0;
  uint64_t conflict_index = 0;
};

// A single-owner, deterministic fixed-three-voter node. Tick is a logical clock;
// Receive returns at most one direct reply and queues any new outbound requests.
// Empty commands are reserved for leadership no-ops. The caller applies ONLY
// TakeCommitted(), in order, and never serves a local read without commitment.
class Node {
 public:
  static constexpr size_t kMaxCommandBytes = 16 * 1024;
  static constexpr size_t kMaxAppendBytes = 32 * 1024;
  static constexpr size_t kMaxAppendEntries = 32;

  struct Config {
    uint64_t id = 0;
    std::vector<uint64_t> voters;
    uint32_t seed = 1;
    uint32_t election_min_ticks = 12;
    uint32_t election_jitter_ticks = 13;
    uint32_t heartbeat_ticks = 2;
    uint32_t rpc_timeout_ticks = 10;
  };

  Node(Config config, DurableState recovered, HardStateStore& hard_store, LogStore& log_store);
  void Tick();
  Status Campaign();
  std::optional<Message> Receive(const Message& message);
  Result<uint64_t> Propose(std::string command);
  Result<std::vector<uint64_t>> ProposeBatch(std::vector<std::string> commands);
  std::vector<Message> TakeMessages();
  std::vector<LogEntry> TakeCommitted();

  bool failed() const { return failed_ || election_.failed() || log_.failed(); }
  bool IsLeader() const { return !failed() && election_.role() == Role::kLeader; }
  Role role() const { return election_.role(); }
  uint64_t id() const { return config_.id; }
  uint64_t term() const { return election_.hard_state().term; }
  uint64_t leader_id() const { return leader_id_; }
  uint64_t LastIndex() const { return log_.LastIndex(); }
  uint64_t CommitIndex() const { return log_.CommitIndex(); }
  const std::vector<LogEntry>& entries() const { return log_.entries(); }

 private:
  struct Progress {
    uint64_t next = 1;
    uint64_t matched = 0;
    uint64_t sequence = 0;
    uint64_t sent_last = 0;
    uint32_t age = 0;
    bool inflight = false;
  };
  void ResetElection();
  void BecomeLeader();
  void SendAppend(uint64_t peer);
  void Broadcast();
  void AdvanceCommit();
  void Collect(std::vector<LogEntry> entries);
  uint64_t NextSequence();
  bool IsPeer(uint64_t peer) const;

  Config config_;
  Election election_;
  RaftLog log_;
  std::minstd_rand random_;
  std::map<uint64_t, Progress> progress_;
  std::vector<Message> messages_;
  std::vector<LogEntry> committed_;
  uint64_t sequence_ = 0;
  uint64_t leader_id_ = 0;
  uint32_t election_elapsed_ = 0;
  uint32_t election_timeout_ = 0;
  uint32_t heartbeat_elapsed_ = 0;
  bool failed_ = false;
};

}  // namespace yewukv::raft
