# Raft (G1 in progress)

`Election` is a deterministic, network-free fixed-three-voter core for term,
vote and majority-election decisions. `RaftLog` handles previous-entry matching,
conflict hints, replacement of uncommitted suffixes, follower commit bounds,
and the current-term-only leader majority rule. Persistence failure poisons
either instance. Tests use both in-memory fault-injection stores and the
disk-backed `FileStore`, which implements `HardStateStore` and `LogStore`.

`FileStore` persists the current term, vote and complete indexed/termed command
log in one checksummed atomic image. It syncs the file before rename and syncs
the directory before success. Reopen validates the complete image; an I/O
failure poisons the instance until reopened. See
[`docs/raft-persistence.md`](../../docs/raft-persistence.md) for crash boundaries,
limits and the difference from the KV WAL.

There is no timer, transport, integrated node,
state-machine apply, or linearizable read path. The wire messages in
`proto/raft.proto` are not connected to this core. See
[`docs/roadmap.md`](../../docs/roadmap.md) for acceptance gates.
