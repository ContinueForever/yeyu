#include "raft/node.h"

#include <algorithm>
#include <iterator>
#include <limits>
#include <stdexcept>
#include <utility>

namespace yewukv::raft {

Node::Node(Config config, DurableState recovered, HardStateStore& hard_store, LogStore& log_store)
    : config_(std::move(config)),
      election_(config_.id, config_.voters, recovered.hard_state, hard_store),
      log_(std::move(recovered.entries), 0, log_store),
      random_(config_.seed + static_cast<uint32_t>(config_.id * 17)) {
  if (config_.heartbeat_ticks == 0 || config_.rpc_timeout_ticks == 0 ||
      config_.election_min_ticks <= config_.heartbeat_ticks ||
      config_.election_jitter_ticks == 0 ||
      config_.election_jitter_ticks > UINT32_MAX - config_.election_min_ticks)
    throw std::invalid_argument("invalid Raft logical clock configuration");
  for (const auto& entry : log_.entries()) {
    if (entry.term > term() || entry.command.size() > kMaxCommandBytes)
      throw std::invalid_argument("recovered log exceeds node term or command limit");
  }
  for (auto peer : config_.voters) {
    if (peer != config_.id) progress_.emplace(peer, Progress{});
  }
  ResetElection();
}

void Node::ResetElection() {
  election_elapsed_ = 0;
  election_timeout_ = config_.election_min_ticks + random_() % config_.election_jitter_ticks;
}

bool Node::IsPeer(uint64_t peer) const { return progress_.count(peer) != 0; }

uint64_t Node::NextSequence() {
  if (sequence_ == std::numeric_limits<uint64_t>::max()) {
    failed_ = true;
    return 0;
  }
  return ++sequence_;
}

void Node::Collect(std::vector<LogEntry> entries) {
  committed_.insert(committed_.end(), std::make_move_iterator(entries.begin()),
                    std::make_move_iterator(entries.end()));
}

Status Node::Campaign() {
  if (failed()) return Status::IOError("Raft node failed; restart required");
  std::vector<OutboundVote> votes;
  const auto status = election_.Campaign(log_.LastIndex(), log_.LastTerm(), &votes);
  if (!status.ok()) return status;
  leader_id_ = 0;
  ResetElection();
  for (const auto& vote : votes) {
    Message message;
    message.kind = MessageKind::kVote;
    message.from = id();
    message.to = vote.peer_id;
    message.sequence = NextSequence();
    message.term = term();
    message.last_index = vote.request.last_log_index;
    message.last_term = vote.request.last_log_term;
    messages_.push_back(std::move(message));
  }
  return failed() ? Status::IOError("Raft sequence exhausted") : Status::OK();
}

void Node::Tick() {
  if (failed()) return;
  if (!IsLeader()) {
    if (++election_elapsed_ >= election_timeout_) Campaign();
    return;
  }
  for (auto& [peer, progress] : progress_) {
    if (progress.inflight && ++progress.age >= config_.rpc_timeout_ticks)
      progress.inflight = false;
  }
  if (++heartbeat_elapsed_ >= config_.heartbeat_ticks) {
    heartbeat_elapsed_ = 0;
    Broadcast();
  }
}

void Node::BecomeLeader() {
  leader_id_ = id();
  heartbeat_elapsed_ = 0;
  for (auto& [peer, progress] : progress_) {
    progress = Progress{};
    progress.next = log_.LastIndex() + 1;
  }
  // A current-term entry establishes commitment of the inherited prefix before
  // any client read can complete, including after an all-node restart.
  auto reply = log_.HandleAppend({log_.LastIndex(), log_.LastTerm(), log_.CommitIndex(),
                                  {{log_.LastIndex() + 1, term(), ""}}});
  if (!reply.ok() || !reply.value().success) {
    failed_ = true;
    return;
  }
  Broadcast();
}

void Node::SendAppend(uint64_t peer) {
  if (!IsLeader()) return;
  auto& progress = progress_.at(peer);
  if (progress.inflight) return;
  Message message;
  message.kind = MessageKind::kAppend;
  message.from = id();
  message.to = peer;
  message.sequence = NextSequence();
  message.term = term();
  message.append.prev_index = progress.next - 1;
  message.append.prev_term = progress.next == 1 ? 0 : log_.entries()[progress.next - 2].term;
  message.append.leader_commit = log_.CommitIndex();
  size_t bytes = 0;
  for (size_t i = static_cast<size_t>(progress.next - 1); i < log_.entries().size(); ++i) {
    const auto& entry = log_.entries()[i];
    if (message.append.entries.size() == kMaxAppendEntries ||
        bytes + entry.command.size() + 24 > kMaxAppendBytes)
      break;
    message.append.entries.push_back(entry);
    bytes += entry.command.size() + 24;
  }
  progress.sequence = message.sequence;
  progress.sent_last = message.append.entries.empty() ? message.append.prev_index
                                                      : message.append.entries.back().index;
  progress.inflight = true;
  progress.age = 0;
  messages_.push_back(std::move(message));
}

void Node::Broadcast() {
  for (const auto& [peer, progress] : progress_) SendAppend(peer);
}

void Node::AdvanceCommit() {
  const auto previous = log_.CommitIndex();
  std::array<uint64_t, 3> matched{log_.LastIndex(), 0, 0};
  size_t i = 1;
  for (const auto& [peer, progress] : progress_) matched[i++] = progress.matched;
  auto result = log_.AdvanceLeaderCommit(term(), matched);
  if (!result.ok()) {
    failed_ = true;
    return;
  }
  Collect(result.TakeValue());
  if (log_.CommitIndex() != previous) Broadcast();
}

std::optional<Message> Node::Receive(const Message& message) {
  if (failed() || message.to != id() || !IsPeer(message.from) || message.term == 0 ||
      message.sequence == 0)
    return std::nullopt;
  const auto before_term = term();
  Message reply;
  reply.from = id();
  reply.to = message.from;
  reply.sequence = message.sequence;
  if (message.kind == MessageKind::kVote) {
    if ((message.last_index == 0) != (message.last_term == 0) || message.last_term > message.term)
      return std::nullopt;
    const auto result = election_.HandleVoteRequest(
        {message.term, message.from, message.last_index, message.last_term},
        log_.LastIndex(), log_.LastTerm());
    if (!result.ok()) return std::nullopt;
    if (term() != before_term) leader_id_ = 0;
    if (result.value().granted) ResetElection();
    reply.kind = MessageKind::kVoteReply;
    reply.term = term();
    reply.granted = result.value().granted;
    return reply;
  }
  if (message.kind == MessageKind::kAppend) {
    reply.kind = MessageKind::kAppendReply;
    reply.term = term();
    if (message.term < term()) return reply;
    size_t bytes = 0;
    if (message.append.entries.size() > kMaxAppendEntries || message.append.prev_term > message.term)
      return std::nullopt;
    for (const auto& entry : message.append.entries) {
      if (entry.term > message.term || entry.command.size() > kMaxCommandBytes)
        return std::nullopt;
      bytes += entry.command.size() + 24;
    }
    if (bytes > kMaxAppendBytes) return std::nullopt;
    if (!election_.ObserveLeader(message.from, message.term).ok()) return std::nullopt;
    leader_id_ = message.from;
    ResetElection();
    const auto result = log_.HandleAppend(message.append);
    if (!result.ok()) {
      // Invalid protocol data never produces an affirmative response. A true
      // persistence/corruption error stops this node rather than losing state.
      if (result.status().code() != StatusCode::kInvalidArgument) failed_ = true;
      return std::nullopt;
    }
    reply.term = term();
    reply.success = result.value().success;
    reply.conflict_index = result.value().conflict_index;
    if (reply.success) {
      reply.match_index = message.append.entries.empty() ? message.append.prev_index
                                                       : message.append.entries.back().index;
      Collect(result.value().newly_committed);
    }
    return reply;
  }
  if (message.term > term()) {
    election_.HandleVoteResponse(message.from, {message.term, false});
    leader_id_ = 0;
    ResetElection();
    return std::nullopt;
  }
  if (message.term != term()) return std::nullopt;
  if (message.kind == MessageKind::kVoteReply) {
    const bool was_leader = IsLeader();
    election_.HandleVoteResponse(message.from, {message.term, message.granted});
    if (!was_leader && IsLeader()) BecomeLeader();
    return std::nullopt;
  }
  if (!IsLeader()) return std::nullopt;
  auto& progress = progress_.at(message.from);
  if (!progress.inflight || message.sequence != progress.sequence) return std::nullopt;
  progress.inflight = false;
  if (message.success) {
    if (message.match_index != progress.sent_last) return std::nullopt;
    progress.matched = std::max(progress.matched, progress.sent_last);
    progress.next = progress.matched + 1;
    AdvanceCommit();
    if (progress.next <= log_.LastIndex()) SendAppend(message.from);
  } else {
    progress.next = std::max(progress.matched + 1,
                             std::min(progress.next - 1, std::max(uint64_t{1}, message.conflict_index)));
    SendAppend(message.from);
  }
  return std::nullopt;
}

Result<uint64_t> Node::Propose(std::string command) {
  auto result = ProposeBatch({std::move(command)});
  if (!result.ok()) return result.status();
  return result.value().front();
}

Result<std::vector<uint64_t>> Node::ProposeBatch(std::vector<std::string> commands) {
  if (failed()) return Status::IOError("Raft node failed; restart required");
  if (!IsLeader()) return Status::Busy("not leader");
  if (commands.empty() || commands.size() > kMaxAppendEntries)
    return Status::InvalidArgument("invalid Raft proposal batch size");
  AppendRequest append{log_.LastIndex(), log_.LastTerm(), log_.CommitIndex(), {}};
  std::vector<uint64_t> indexes;
  for (auto& command : commands) {
    if (command.empty() || command.size() > kMaxCommandBytes)
      return Status::InvalidArgument("invalid Raft command size");
    const uint64_t index = log_.LastIndex() + append.entries.size() + 1;
    indexes.push_back(index);
    append.entries.push_back({index, term(), std::move(command)});
  }
  const auto result = log_.HandleAppend(append);
  if (!result.ok()) return result.status();
  if (!result.value().success) {
    failed_ = true;
    return Status::Corruption("local Raft append rejected");
  }
  Broadcast();
  return indexes;
}

std::vector<Message> Node::TakeMessages() { return std::exchange(messages_, {}); }
std::vector<LogEntry> Node::TakeCommitted() { return std::exchange(committed_, {}); }

}  // namespace yewukv::raft
