# yewukv

A distributed key-value service built in modern C++, with a fixed-three-node
Raft group, strongly consistent reads/writes and durable state-machine snapshots.

> Status: **fixed-three-node Raft development service** — durable term/vote/log,
> elections, bounded replication batches, majority commit and ordered KV apply
> run over TCP/Protobuf. Reads also commit through the log. Tests exercise leader
> SIGKILL, peer partitions, full restart and bounded concurrent-history checking.
> Atomic KV/Raft snapshots, bounded log reclamation and chunked snapshot transfer
> are implemented, with crash, capacity and resource-failure tests. Local deployment,
> checked backup/restore and repeatable load tools are available. This is a bounded
> prototype: no LSM, sharding or cross-machine/production acceptance
> (see the [roadmap](docs/roadmap.md)).

## Three-node quick start

After building, on a Linux desktop with user systemd:

```bash
scripts/local-cluster.sh install
scripts/local-cluster.sh status
scripts/local-cluster.sh put hello world
scripts/local-cluster.sh get hello
scripts/local-cluster.sh restart
scripts/local-cluster.sh get hello
```

The nodes listen on loopback ports 9101–9103 and use separate persistent
directories. The CLI discovers the highest-term reported leader and only
retries explicit pre-append `NOT_LEADER` rejections. A timed-out or unavailable
write has an unknown outcome. See [cluster operation and limits](docs/cluster.md)
and [the batching experiment](benchmarks/cluster-baseline-20261020.md).

## Long-term architecture (target)

```text
Client SDK / CLI / Redis-compatible gateway
            │  TCP, length-prefixed frames + Protobuf RPC
            ▼
Reactor network layer   (epoll, one loop per thread, framing)
            │  key → Raft Group routing
            ▼
Multi-Raft consensus    (election, log replication, snapshot, membership)
            │  apply committed entries
            ▼
Storage engine          (WAL → SkipList MemTable → SSTable + BloomFilter)
```

## Current implementation

- Non-blocking TCP server: `epoll` Reactor, one-loop-per-thread worker pool,
  growable read/write buffers, cross-loop task handoff via `eventfd`.
- Line-based text protocol for bring-up:
  `PUT <k> <v>`, `GET <k>`, `DEL <k>`, `PING` (RESP-ish replies).
- `--protocol rpc`: 4-byte length-prefixed Protobuf KV requests and responses,
  correlation IDs, a reusable asynchronous client with futures and deadlines.
- `KVEngine` with a checksummed WAL and in-memory ordered map.
  A single FIFO storage worker executes KV operations outside I/O loops; startup
  replays the WAL before accepting requests. The WAL can atomically compact to
  the current live map when its 1 GiB file limit is reached.
- Network-free Raft helpers check term/vote, candidate log freshness, log
  matching and majority commit. `raft::FileStore` implements their durable
  hard-state and log interfaces, with atomic images, exclusive directory
  ownership, CRC validation and SIGKILL recovery tests. `raft::Node` coordinates
  them using a logical clock; `yewukv-node` connects peer RPC, real timers and KV
  state-machine application. See [Raft persistence](docs/raft-persistence.md)
  for the format, limits and integration contract.
- GoogleTest and process-level TCP coverage for the network layer, framing,
  async client, storage queue, request ordering, limits, concurrency and shutdown.
  WAL recovery tests cover torn tails, damaged complete records, exclusive
  directory ownership, and acknowledged writes after SIGKILL and restart.
- Bounded text line (64 KiB), input buffer (128 KiB), output buffer (1 MiB)
  and connection count (1024); `--storage-queue <count>` sets the storage
  operation limit to 1–8192 (default 4096). A full queue returns `-ERR busy`
  or RPC `BUSY` (code 4). SIGINT/SIGTERM drain responses with a one-second
  event-loop deadline.
- Idle TCP connections expire after 60 seconds without a successful read or
  write; `--idle-timeout <seconds>` configures 0–86400 seconds (0 disables it).
  Both protocols share this policy; checks run once per second.

## Build

With system packages providing g++, CMake, Ninja, Protobuf and GoogleTest:

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j2
ctest --test-dir build --output-on-failure -j2
```

The server defaults to `--data-dir data`; pass the same directory after restart
for WAL recovery.
The optional original user-space toolchain uses a micromamba environment at
`~/.micromamba/envs/yewu`:

```bash
source scripts/env.sh        # activate toolchain
scripts/build.sh             # configure + build (Ninja)
scripts/test.sh              # ctest (includes local TCP integration test)
```

Binaries are emitted under `build/bin/`.

To run under AddressSanitizer and UndefinedBehaviorSanitizer:

```bash
source scripts/env.sh
cmake -S . -B build-asan -G Ninja -DCMAKE_BUILD_TYPE=Debug \
  -DYEWUKV_ENABLE_SANITIZERS=ON -DCMAKE_PREFIX_PATH="$YEWU_ENV"
cmake --build build-asan -j4
ctest --test-dir build-asan --output-on-failure
```

If LeakSanitizer cannot inspect processes in a restricted container, set
`ASAN_OPTIONS=detect_leaks=0` for the build and test commands. AddressSanitizer
and UndefinedBehaviorSanitizer remain active in that mode.

## Run

```bash
./build/bin/yewukv-server --port 9000 --io-threads 4 --data-dir data
# in another shell (or use nc/python):
python3 - <<'PY'
import socket
s = socket.create_connection(("127.0.0.1", 9000))
s.sendall(b"PING\nPUT foo bar\nGET foo\n")
print(s.recv(4096).decode())
PY
```

The current Compose deployment is one durable node, not a Raft cluster:

```bash
docker compose -f deploy/docker-compose.yml up --build -d
./build/bin/yewukv-client --port 9000 put foo bar
docker compose -f deploy/docker-compose.yml restart node
./build/bin/yewukv-client --port 9000 get foo
```

Compose stores the WAL in the `node-data` volume. The client commands above
require a local build; alternatively run the client inside the container.
For a repeatable write/restart/container-recreation check that cleans up its
own Compose project and volume, run `scripts/ci-compose-smoke.sh`.

To exercise the framed RPC mode with the C++ client:

```bash
./build/bin/yewukv-server --port 9001 --io-threads 4 --protocol rpc
# in another shell:
./build/bin/yewukv-client --port 9001 ping
./build/bin/yewukv-client --port 9001 put foo bar
./build/bin/yewukv-client --port 9001 get foo
```

For example, `--idle-timeout 300` keeps inactive connections for five minutes.
Idle eviction closes the transport, including incomplete requests and stalled
output. Clients should send periodic requests or create a new client after an
idle disconnect; the C++ RPC client does not reconnect automatically.

Text is still the default server protocol. Each listening port serves one
protocol mode. RPC calls are not retried automatically; a timed-out write may
still have been applied. Accepted operations execute in one FIFO storage order,
and replies on each connection preserve request order. Successful PUT/DEL
responses follow a synced WAL record or a synced replacement WAL that includes
the deletion. A timed-out or disconnected client cannot infer
whether an accepted write ran. The storage worker drains accepted work during
shutdown; the one-second TCP response deadline can expire first if a storage
operation blocks.
WAL records use a versioned binary format with a sequence number and CRC32.
Incomplete final records are truncated during recovery; checksum or format
corruption fails startup. The server takes an exclusive lock on the data
directory. The WAL is capped at 1 GiB. When an append would exceed it, the
engine writes a compacted replacement containing live keys and retries; writes
return BUSY if the live set plus the new record cannot fit. Use a stable local
filesystem that honors `fdatasync` and `fsync` for the durability guarantee.

See [the RPC design notes](docs/design.md#m1--framed-kv-rpc) and
[development baseline instructions](benchmarks/README.md). The initial
[RPC baseline](benchmarks/rpc-baseline-20260924.md) and
[WAL baseline](benchmarks/rpc-wal-baseline-20260925.md) include machine-specific
reports and raw samples from local runs.

## Roadmap

The original single-node service remains available. A fixed-three-node Raft
service now integrates the durable cores, with initial failure, operational
and performance evidence. Longer failure campaigns, cross-machine acceptance,
and cross-machine acceptance remain. Snapshot/reclamation and local resource-failure
acceptance are implemented; see [snapshot design](docs/snapshots.md). See the
[six-month roadmap](docs/roadmap.md) for acceptance criteria and scope limits.

## Layout

```
src/common/   Status/Result, logging
src/net/      Reactor: EventLoop, Poller(epoll), Channel, Acceptor, TcpServer
src/rpc/      length-prefixed Protobuf RPC and asynchronous client
src/raft/     durable state, deterministic election/log rules and node state machine
src/cluster/  three-node runtime, peer RPC, committed KV apply and diagnostics
src/storage/  KVEngine, WalEngine + recovery, MemEngine
src/kv/       command protocol + server wiring
proto/        Protobuf schemas
app/          server executable
tests/        GoogleTest unit tests
deploy/       original single-node durable Docker Compose config
scripts/      toolchain/build/test helpers
benchmarks/   YCSB/self-built load generators (M6)
docs/         design notes
```

## Toolchain notes

For a user-space toolchain, install dependencies with
[micromamba](https://mamba.readthedocs.io/):

```bash
micromamba create -n yewu -c conda-forge \
  gxx_linux-64=14 cmake ninja libprotobuf gtest clang-tools ccache
```

`scripts/env.sh` points CC/CXX/CMAKE_PREFIX_PATH at that environment.
