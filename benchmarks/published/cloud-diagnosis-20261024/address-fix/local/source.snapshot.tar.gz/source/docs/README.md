# 文档导航

当前实现为固定三个 voter、单 Raft Group 的 C++17 KV 服务，默认使用增量 journal、ReadIndex 和自适应快照。已有同机三进程回归与性能证据、三台 ECS 基础正确性演练，以及 45 轮跨机性能基线与逐请求样本归档，见下方对应报告。

## 使用与开发

| 需要做的事 | 入口 |
| --- | --- |
| 构建、测试、启动和读写 | [项目首页](../README.md) |
| 修改代码与提交前检查 | [开发说明](../CONTRIBUTING.md) |
| 本机服务、状态、超时、备份和恢复 | [集群操作](cluster.md) |
| 三台云服务器私网部署与系统级服务 | [云服务器部署](cloud-deployment.md) |
| 对现有三机测吞吐量、P95/P99 和不同并发 | [跨机压测操作](cloud-benchmark.md) |
| 关联读请求、ReadIndex 与副本 RPC 的分阶段耗时 | [读路径追踪](read-tracing.md) |
| 配置发布、HTTP 消费者和动态刷新 | [配置应用](../examples/README.md) |
| 跑性能对照或故障活动 | [实验复现](../benchmarks/README.md) |
| 当前进度、后续方向和放行标准 | [工程路线](roadmap.md) |

## 设计与正确性契约

| 主题 | 文档 |
| --- | --- |
| 网络、存储与模块边界 | [总体设计](design.md) |
| 状态机、持久化和传输层的职责 | [Raft 集成契约](raft-contract.md)、[模块说明](../src/raft/README.md) |
| 文件格式、校验、原子发布和失败处理 | [Raft 持久化](raft-persistence.md)、[增量 journal](journal.md) |
| 新鲜多数派确认、应用位置和读写重叠 | [ReadIndex](read-index.md) |
| 快照触发、日志回收、容量和磁盘兼容性 | [快照契约](snapshots.md) |

## 实验与验收

按时间从新到旧排列。每份报告注明对应版本、负载、恢复检查、限制与证据状态。云端归档保留故障输出、环境、服务日志及新增的逐请求性能样本；同机归档另有模型历史。各自的源码快照与文件清单可离线核验。

| 版本与变化 | 回归 | 性能与故障活动 | 原始证据 |
| --- | --- | --- | --- |
| [2026-10-24：三台 ECS 跨机性能基线](cloud-performance-20261024.md) | 节点仍为已验收的 `909df76` 二进制，工具为 `c1b238c`；未重新执行云端 CTest | 45 轮、1,954,767 次计时请求；三种读写负载、五档并发、三次重复；保留高并发读尾延迟与最坏单次 152.175 ms | [核验入口](../benchmarks/published/cloud-performance-20261023/README.md)：逐请求样本、三台环境、CSV、图表与源码 |
| [2026-10-23：三台 ECS 基础正确性手工演练](cloud-acceptance-20261023.md) | 三台各 126 项普通构建通过，源码与运行二进制哈希一致 | 两次服务停止接管、一个 Follower 虚拟机重启、少数派保护及全停恢复；无跨机性能测量 | [核验入口](../benchmarks/published/cloud-20261023/README.md)：五项故障的文本记录；初始三条读写序列只有截图 |
| [2026-10-22：读写重叠、自适应快照与 CRC 优化](local-followup-20261022.md) | 普通／sanitizer 各 125 项，磁盘补充 43 项 | 72 轮、4,353,146 次计时操作；一小时、3,302 轮、176,543 次模型操作 | [核验入口](../benchmarks/published/local-followup-20261022/README.md) |
| [2026-10-21：增量 journal、ReadIndex 与配置应用](local-optimization-20261021.md) | 普通／sanitizer 各 120 项，磁盘补充 13 项 | 36 轮、1,265,078 次计时操作；20 分钟、1,143 轮、61,113 次模型操作 | [核验入口](../benchmarks/published/local-optimization-20261021/README.md) |
| [2026-10-21：image／日志读与快照基线](local-acceptance-20261021.md) | 普通／sanitizer 各 103 项 | 27 轮、348,770 次计时操作；15 分钟、948 轮、50,970 次模型操作 | [核验入口](../benchmarks/published/local-20261021/README.md) |

验收日志中的“磁盘补充”不与完整回归数相加。性能操作、并发模型操作和顺序持久值检查分别计数。较早的单节点实验位于 `benchmarks/results/` 中已跟踪的历史目录，解释见[实验说明](../benchmarks/README.md)。

2026-10-22 的同机性能报告保留了均衡负载 P99.9 变差及大状态单次约 164 ms 的结果。新增三机基线也保留了纯读高并发尾部和写密集轮次中单次 152.175 ms 的 GET。检查点仍同步生成；这些有限实验不包含真实断电、多日稳定性或生产容量验收。
