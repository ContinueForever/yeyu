# Raft 核心契约（G1）

当前已有[选举内核](../src/raft/election.h)、[日志规则内核](../src/raft/log.h)、[磁盘存储](../src/raft/file_store.h)及[节点状态机](../src/raft/node.h)，并通过 `cluster::Server` 接入三节点 TCP/RPC 服务。本文固定集成边界，避免把现有状态机 WAL 错当作共识日志。共识安全规则以 [Raft 论文 Figure 2](https://raft.github.io/raft.pdf) 为准。

## 输入、输出与持久化

- 固定三个非零、互异的 voter ID；节点状态包括 `currentTerm`、`votedFor`、角色和本轮已获票集合。角色与已获票集合只驻内存；重启后恢复为 follower。
- `Campaign` 在发出 RequestVote 之前，必须先持久化新任期和自己的投票；给对端的日志末尾 index/term 必须来自**已持久化**的 Raft 日志。
- 处理 RequestVote 时，比较候选人的末尾日志 term，term 相同再比较 index；一个任期只给一个候选人投票。任期或投票变化要先持久化，再回复准许投票。
- 处理更高任期的投票回复或有效 Leader 消息时，先持久化新任期与清空的投票，再降为 follower。持久化失败使节点停止参与选举；调用方必须关闭此实例并从持久状态恢复，不能继续使用旧任期服务请求。
- 日志规则内核在前项 index/term 匹配后才接受追加；只替换未提交的冲突后缀，持久化成功才确认追加。Follower 的 commit 不得超过本次 Leader 消息中确认存在的最后条目；Leader 只能用当前任期的多数派条目推进 commit，旧任期条目随之提交。
- 模拟器显式投递消息并驱动逻辑超时，核心不读取实时时钟或网络。当前测试覆盖重复投票、重启后拒绝第二张票、日志新旧比较、冲突提示、已提交条目保护、多数派与持久化失败，并使用 100 个固定种子、每个 1000 步，混合隔离、丢包、重排、重复回复、快照和重启，检查任期选举唯一性及已提交前缀不变。

## 已实现的持久化基础

`FileStore` 默认将 term/vote 和带 index、term 的日志变更同步追加到 journal，按代次原子发布检查点；原 image 模式仍保留。只有相应持久化成功才返回成功，格式和原子性见[journal 契约](journal.md)。重启恢复、真实进程 SIGKILL、持久化边界故障注入和损坏镜像检查已有测试。格式、接口示例和容量边界见[持久化说明](raft-persistence.md)。

当前 `WalEngine` 记录的是**已经应用**的 KV 变更，格式没有 Raft term/index，也不能表示完整但未提交的日志；不能将它直接当作 Raft 复制日志。

## 节点集成约束

选举、日志及磁盘存储由同一个节点状态机串行驱动。接收方先检查固定成员 ID、目标 ID、消息序号及任期，持久化新 term/vote 后才交给日志核心；发起投票或确认追加之前等待存储成功。Leader 使用 `nextIndex/matchIndex` 及关联请求序号处理回复，忽略旧回复；按条数和字节数切分复制批次。配置文件将磁盘目录绑定到固定 node ID 和成员地址，拒绝更换配置后复用数据。

新 Leader 先持久化当前任期的 no-op。PUT/DEL/PING 追加日志，由多数派提交后按序应用。GET 默认使用[ReadIndex](read-index.md)，取得本轮多数派确认并等待应用位置；可选 log 模式保留旧路径。`status` 是本地诊断，不能作为一致性读接口。角色改变后先取消旧 Leader 的等待请求，再应用新提交日志，避免同一个索引被替换后错误回应旧请求。

`FileStore` 默认[增量追加 journal](journal.md)，在检查点将快照的 lastIncludedIndex/Term、KV 状态、hard state 与剩余日志原子保存。启动先恢复快照及其 applied/commit 下界；快照之后的日志由协议重新确认提交后回放，未提交尾部不会直接应用。无快照的 v1 镜像仍从空状态机恢复。详见[快照契约](snapshots.md)。

本机真实进程测试已覆盖 Leader SIGKILL、客户端可达但 peer 链路完全隔离、旧 Leader 回归、全节点重启、日志追赶及并发历史校验。三台 ECS 的服务停止接管、少数派保护与正常重启恢复见[基础手工记录](cloud-acceptance-20261023.md)，导出的文本与环境已有离线核验归档。当前证据为有界测试及有限手工观测，不是形式化证明；真实断电及成员变更尚未验收。本机快照、资源失败和持续故障验收记录见[本轮验收报告](local-acceptance-20261021.md)。
